# ⚡ PowerTrade Options Intelligence Terminal v5

**Alpha Generation Engine** — Institutional-grade crypto options intelligence with four active signal modules.

![Version](https://img.shields.io/badge/version-5.0-00e5ff)
![License](https://img.shields.io/badge/license-MIT-green)
![Status](https://img.shields.io/badge/status-live-brightgreen)

## What's New in v5

v5 transforms the terminal from passive data monitoring to **active alpha generation** with four institutional-grade signal modules:

| Module | Location | Signal Type |
|--------|----------|-------------|
| **Gamma Flip & Zero-Gamma Levels** | Positioning tab | Volatility regime trigger zones |
| **Relative Value Vol Arbitrage** | Options Lab tab | Z-score based IV spread dislocations |
| **VRP Decay Optimizer (TVE)** | Options Lab tab | Theta-to-Vega efficiency rankings |
| **Intent-Based Flow Aggregator** | All flow feeds | Complex spread detection |

## Quick Start

**Zero dependencies. Single HTML file. Just open it.**

```bash
git clone https://github.com/YOUR_USERNAME/powertrade-terminal.git
open powertrade-terminal/index.html
```

Or deploy to GitHub Pages for live access (see below).

## Architecture

Single-file application (~3000 lines) with:
- **67 tokens** across L1, L2, DeFi, AI, Meme, RWA categories
- **70 functions** (10 new alpha module functions in v5)
- **8 canvas visualizations** including gamma profiles and z-score charts
- **7 tabs**: Signal Feed, Dashboard, Options Lab, Positioning, Scanner, Fair Value, Intel
- **7-second live tick** with stochastic IV/funding/skew evolution

### Alpha Modules

**1. Gamma Flip & Zero-Gamma Levels**
Calculates the price where aggregate Dealer GEX crosses zero using a bell-curve gamma distribution across 25 strike levels. Zero-crossing found via linear interpolation. Canvas visualization with positive/negative GEX fill regions, gamma wall detection, and volatility trigger zone alerts.

**2. Relative Value Volatility Spreads**
Rolling z-score of ETH/BTC, SOL/BTC, SOL/ETH IV ratios. Signals at ±2σ from 30-period mean. Time-series canvas with ±1σ/±2σ bands. Actionable arb signals like "Sell ETH straddle, Buy BTC straddle" when ETH vol is statistically rich.

**3. VRP Decay Optimizer**
Ranks 15 assets × 5 expiries = 75 combinations by Theta-to-Vega Efficiency score:
`TVE = (Θ/day ÷ Vega) × (1 + VRP × 3) × (1 ÷ (GapRisk + 0.1))`
Identifies optimal short-vol positions for maximum theta income with minimum gap risk.

**4. Intent-Based Flow Aggregator**
Detects multi-leg institutional trades within 1-second windows. Classifies Vertical Spreads, Straddles, Strangles, Calendars, and Risk Reversals. Generates human-readable intent descriptions with paired leg connectors.

## Deploy to GitHub Pages

1. Push to GitHub
2. Settings → Pages → Source: main branch, / (root) → Save
3. Live at `https://YOUR_USERNAME.github.io/powertrade-terminal/`

## Tech Stack

Pure HTML/CSS/JS — no build tools, no frameworks, no dependencies. Canvas API for visualizations, CSS Variables for theming, DM Sans + Space Mono fonts. Optional Anthropic Claude API integration for the AI command bar.

## License

MIT — see [LICENSE](LICENSE)

---

**Built for [PowerTrade](https://power.trade)** · [Market Insights](https://power.trade/en/market-insights) · Not Financial Advice
