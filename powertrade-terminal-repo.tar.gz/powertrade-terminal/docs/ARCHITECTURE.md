# Architecture — Alpha Generation Modules

## Module 1: Gamma Flip & Zero-Gamma Levels

### Theory
Dealer gamma sign determines volatility regime:
- **Positive GEX**: Dealers are long gamma → they buy dips and sell rips → dampens volatility
- **Negative GEX**: Dealers are short gamma → they sell weakness and buy strength → amplifies volatility
- **Gamma Flip Price**: The zero-crossing point where the regime changes

### Implementation
```
calcGammaProfile(sym)
├── Generates 25 strike levels ±18% from spot
├── Gamma at each strike: exp(-moneyness² / (2σ²))
├── Sign: positive below spot, negative above (dealer positioning)
├── Zero-crossing: K_flip = K₀ + (0 - g₀)/(g₁ - g₀) × (K₁ - K₀)
└── Gamma Wall: argmax |GEX(K)|

drawGammaProfile(canvasId, sym, metaId, zoneId)
├── Green fill: positive GEX region
├── Red fill: negative GEX region
├── Amber dashed: flip level
├── Cyan dashed: gamma wall
└── Yellow zone: trigger band (±1.5%)
```

### Integration
- Location: Positioning tab, after GEX zones
- Update: Every tick via renderAll → drawGammaProfile
- Metadata: Flip price, Δ from spot, regime, vol effect, wall price

---

## Module 2: Relative Value Volatility Spreads

### Theory
IV ratios between correlated assets (ETH/BTC, SOL/BTC, SOL/ETH) mean-revert. When the ratio deviates beyond ±2σ from its rolling mean, a statistical arbitrage opportunity exists.

### Formula
```
z = (current_ratio - μ) / σ

Where:
  current_ratio = ETH_IV / BTC_IV
  μ = rolling 30-period mean of ratio
  σ = rolling standard deviation
```

### Signals
| Z-Score | Signal | Action |
|---------|--------|--------|
| z > +2σ | ETH vol rich | Sell ETH straddle, Buy BTC straddle |
| z < −2σ | ETH vol cheap | Buy ETH straddle, Sell BTC straddle |
| |z| > 1.5σ | Approaching | Monitor for breakout |
| |z| < 1.5σ | Neutral | No action |

### Integration
- Data: `ivRatioHistory` — rolling 60-period buffers for 3 pairs
- Update: `updateIVRatios()` called every tick
- Canvas: Time-series with ±1σ (cyan) and ±2σ (amber) bands

---

## Module 3: VRP Decay Optimizer

### Theory
The optimal short-volatility position maximizes theta income while minimizing vega exposure and directional gap risk. The TVE (Theta-to-Vega Efficiency) score ranks all asset × expiry combinations.

### Formula
```
TVE = (Θ/day ÷ Vega) × (1 + VRP_factor × 3) × (1 ÷ (Gap_Risk + 0.1))

Where:
  Θ/day ≈ S × σ / √(2π × DTE/365) / 365     (ATM straddle daily theta)
  Vega  ≈ S × √(DTE/365) × 0.3989             (ATM option vega, N'(0) ≈ 0.3989)
  VRP_factor = max(0, IV − RV) / RV            (vol risk premium as fraction of RV)
  Gap_Risk = IV × √(365/DTE) × Fund_Penalty    (higher for short-dated + extreme funding)
  Fund_Penalty = 1 + |funding_rate| × 20
```

### Scoring
- **70-100**: Strong sell-vol opportunity (green)
- **40-69**: Moderate opportunity (amber)
- **0-39**: Poor risk/reward (red)

### Integration
- Iterates 15 liquid assets × 5 expiries = 75 combinations
- Normalized to 0-100 scale, sorted descending, shows top 20
- Location: Options Lab tab, below strategy ideas

---

## Module 4: Intent-Based Flow Aggregator

### Theory
Institutional traders execute complex multi-leg strategies, not independent trades. Detecting legs within a time window on the same asset reveals true positioning intent.

### Detection Rules
Same asset, within 1-second window:

| Leg A Type | Leg B Type | Same Strike? | Same Expiry? | Classification |
|------------|------------|:------------:|:------------:|----------------|
| Same | Same | No | Yes | **Vertical Spread** |
| Different | Different | Yes | Yes | **Straddle** |
| Different | Different | No | Yes | **Strangle** or **Risk Reversal** |
| Same | Same | Yes | No | **Calendar Spread** |

### Intent Mapping
- **Call Vertical (debit)**: "Bullish · Capped upside · Defined risk"
- **Put Vertical (credit)**: "Bullish · Credit put spread · Theta income"
- **Straddle**: "Non-directional · Vol play · Expecting large move"
- **Strangle**: "Non-directional · Wide vol play · Lower cost than straddle"
- **Calendar**: "Vol term structure trade · Capturing time decay differential"
- **Risk Reversal**: "Directional · Skew trade · Synthetic delta position"

### Integration
- `detectComplexSpreads()` runs after initial flow generation and on new spread pairs
- Flow items tagged with `spreadType`, `spreadLabel`, `linkedIdx`, `intent`
- `renderFlowFeed()` adds purple left border, colored spread tags, intent lines, and leg connectors
- "🔗 Spreads" filter pill added to both Signal Feed and Options Lab flow feeds
